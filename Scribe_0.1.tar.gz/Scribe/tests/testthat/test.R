#test InformationEstimator
require(Rcpp)

cppFunction("
NumericMatrix exfun(NumericMatrix x){
  NumericMatrix::
}
            ")