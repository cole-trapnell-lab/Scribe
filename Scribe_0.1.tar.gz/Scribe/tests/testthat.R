library(testthat)
library(InformationEstimator)

test_check("InformationEstimator")
