## ----include=FALSE-------------------------------------------------------
library(knitr)
opts_chunk$set(
#concordance=TRUE
)

## ----package_loads, include=FALSE, eval=TRUE-----------------------------
library(Biobase)
library(knitr)
library(reshape2)
library(ggplot2)

knitr::opts_chunk$set(autodep=TRUE, cache=FALSE, warning=FALSE, dev='png', dpi=600)
set.seed(0)

## ----init_Scribe, include=FALSE, eval=TRUE-------------------------------
library(Scribe)
library(plyr)

## ----load_the_neuron_simulation_data, eval = TRUE------------------------
rm(list = ls())
load("/Users/xqiu/Dropbox (Cole Trapnell's Lab)/Monocle 2/first_revision/Monocle2_revision/RData/fig3.RData") # cds data
load('/Users/xqiu/Dropbox (Personal)/Projects/Causal_network/causal_network/RData/neuron_network') # network data

# neuron_network not exist
neuron_network$Type <- c('Neuron', 'Oligo', 'Astro', 'Neuron', 'AO', 
                         'Neuron', 'Neuron', 'Neuron', 'Neuron', "Neuron", 
                         'AO', 'AO', 'Astro', 'Oligo', 'Olig', 'Astro', 
                         'Astro', 'Astro', 'Olig', 'Astro', 'Oligo')

# 
fData(neuron_sim_cds)$gene_short_name <- fData(neuron_sim_cds)$gene_short_names
fData(na_sim_cds)$gene_short_name <- fData(na_sim_cds)$gene_short_names


## ----load_the_lung_data, eval = F----------------------------------------
#  # add code here for demo of the lung dataset
#  

## ----gene_pairwise_kinetic_plot, eval = TRUE, fig.width = 4, fig.height = 2.5, fig.align="center"----
# show the pair-wise gene plot:   
neuron_sim_cds@lowerDetectionLimit <- 0.01
exprs(neuron_sim_cds) <- 10^(exprs(neuron_sim_cds)) #increase the data avoid the fitting issue
exprs(na_sim_cds) <- 10^(exprs(na_sim_cds)) #increase the data avoid the fitting issue
plot_gene_pairs_in_pseudotime(neuron_sim_cds[, ], gene_pairs_mat =  as.matrix(neuron_network[1, 1:2]), n_row = 1, n_col = 1) + 
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
plot_gene_pairs_branched_pseudotime(na_sim_cds, gene_pairs_mat = as.matrix(neuron_network)[1:2, 1:2], n_row = 2, n_col = 2) + 
  monocle:::monocle_theme_opts() + xacHelper::nm_theme() # neuron_sim_cds is not a branch trajectory 


## ----gene_pairwise_plot, eval = TRUE, fig.width = 2, fig.height = 2, fig.align="center"----
# we skip some functions below because they uses plotly package whose figures can be rendered in a pdf file 
plot_lag_drevi(neuron_sim_cds, matrix(c('Zic1', 'Sox8', 'Brn2', 'Myt1L', 'Tuj1', 'Stat3'), ncol = 2, byrow = T)) + 
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()

x <- exprs(neuron_sim_cds)['Pax6', ]
y <- exprs(neuron_sim_cds)['Mash1', ]
z <- exprs(neuron_sim_cds)['Hes5', ]

# plot_rdi_gene_pairs(x, y)

# plot_ly(type = 'scatter3d', x = log10(x), y = log10(y), z = log10(z), mode = 'markers') # show the original space
# 
# # plot CCM state space and the the scatter plot in three dimension
# plot_ccm(x) # Pax lagged state space looks pretty random
# 
# plot_ccm(log10(y)) #Pax lagged state space looks pretty random
# 
# plot_ccm(z) #Pax lagged state space looks pretty random


## ----plot_drevi, eval = TRUE, fig.width = 4, fig.height = 2, fig.align="center"----
# show the drevi plot result for all existing edges:
plot_lag_drevi(neuron_sim_cds[, 1:200], gene_pairs_mat = as.matrix(neuron_network[c(1, 3), 1:2]), d = 1, n_row = 1, n_col = 2) +
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()
plot_lag_drevi(neuron_sim_cds[, 1:200], gene_pairs_mat = matrix(c('Zic1', 'Sox8', 'Brn2', 'Myt1L'), byrow = T, nrow = 2), n_row = 1, n_col = 2, scales = 'free') + 
  monocle:::monocle_theme_opts() + xacHelper::nm_theme()

## ----plot_temporal_rdi, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center"----
# test temporal RDI, etc.
gene_name_vec <- c('Pax6', 'Mash1', 'Brn2', 'Zic1', 'Tuj1', 'Hes5', 'Scl', 'Olig2', 'Stat3', 'Myt1L', 'Aldh1L', 'Sox8', 'Mature')

rdi_crdi_pseudotime_res_list <- rdi_crdi_pseudotime(t(exprs(na_sim_cds)[1:12, 1:200]), window_size = 50) #13 mature gives Na values

rdi_res <- rdi_crdi_pseudotime_res_list$rdi_res
crdi_res <- rdi_crdi_pseudotime_res_list$crdi_res

dim(rdi_res) <- c(dim(rdi_res)[1], dim(rdi_res)[2] * dim(rdi_res)[2])

all_cmbns <- expand.grid(gene_name_vec[1:12], gene_name_vec[1:12])
valid_all_cmbns_df <- data.frame(pair = paste((all_cmbns$Var1), (all_cmbns$Var2), sep = ' -> '), pval = 0)

row.names(valid_all_cmbns_df) <- valid_all_cmbns_df$pair
rdi_res <- as.data.frame(rdi_res)
colnames(rdi_res) <- valid_all_cmbns_df$pair

valid_all_cmbns_df <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
valid_rdi_res <- rdi_res[, as.character(valid_all_cmbns_df$pair)]
norm_valid_rdi_res <- apply(valid_rdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
pheatmap::pheatmap(t(norm_valid_rdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)

valid_all_cmbns_df_back <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
valid_rdi_res_back <- rdi_res[, as.character(valid_all_cmbns_df_back$pair)]
norm_valid_rdi_res_back <- apply(valid_rdi_res_back, 2, function(x) (x - min(x)) / (max(x) - min(x)))
pheatmap::pheatmap(t(norm_valid_rdi_res_back[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)

# plot crdi_res
dim(crdi_res) <- c(dim(crdi_res)[1], dim(crdi_res)[2] * dim(crdi_res)[2])

valid_all_cmbns_df <- data.frame(pair = paste((all_cmbns$Var1), (all_cmbns$Var2), sep = ' -> '), pval = 0)
colnames(crdi_res) <- valid_all_cmbns_df$pair

valid_all_cmbns_df <- data.frame(pair = paste((as.character(neuron_network[, 1])), (as.character(neuron_network[, 2])), sep = ' -> '), pval = 0)
valid_crdi_res <- crdi_res[, as.character(valid_all_cmbns_df$pair)]
norm_valid_crdi_res <- apply(valid_crdi_res, 2, function(x) (x - min(x)) / (max(x) - min(x)))
# norm_valid_crdi_res_ordered <- norm_valid_crdi_res[, order(unlist(apply(norm_valid_crdi_res, 2, which.max)))]
pheatmap::pheatmap(t(norm_valid_crdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)

pheatmap::pheatmap(t(norm_valid_crdi_res[, ]), cluster_rows = F, cluster_cols = F, annotation_names_row = T, border_color = NA)

neuron_net <- graph_from_edgelist(as.matrix(neuron_network[, 1:2]), directed = T)

layout_coord <- layout_as_tree(neuron_net)
row.names(layout_coord) <- V(neuron_net)$name
layout_coord["Tuj1", ] <- c(-1.25,  0)

layout_coord["Scl", ] <- layout_coord["Olig2", ]
layout_coord["Olig2", ] <- c(1.25, 1.00)
layout_coord["Stat3", ] <- c(0.4, 0.5)
layout_coord["Aldh1L", ] <- c(-0.75, -1)
layout_coord["Myt1L", ] <- layout_coord["Sox8", ]
layout_coord["Sox8", ] <- c(1.95, 0)

color = rep('blue', 21)
color[c(5, 12, 14, 16)] <- 'red'

res <- apply(norm_valid_crdi_res, 2, function(x) c(mean(x[1:37]), mean(x[38:64]), mean(x[65:111]), mean(x[112:150])))
plot(neuron_net, layout = layout_coord, edge.width=res[1, ] * 5, edge.color = color)
plot(neuron_net, layout = layout_coord, edge.width=res[2, ] * 5, edge.color = color)
plot(neuron_net, layout = layout_coord, edge.width=res[3, ] * 5, edge.color = color)
plot(neuron_net, layout = layout_coord, edge.width=res[4, ] * 5, edge.color = color)


## ----plot_time_delay_heatmap, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center"----
na_sim_cds <- estimate_turning_point(na_sim_cds)
plot_time_delay_heatmap(na_sim_cds, use_gene_short_name = F)

## ----plot_network, eval = TRUE, fig.width = 4, fig.height = 4, fig.align="center"----

data <- t(exprs(neuron_sim_cds)[, 1:200]) # prepare the data (row is sample, column is gene)
noise = matrix(rnorm(mean = 0, sd = 1e-10, nrow(data) * ncol(data)), nrow = nrow(data))

run_vec <- rep(1, nrow(data)) # run information for each cell

# create the network graph we want to estimate RDI (here we calculate all possible pair of gene regulation)
tmp <- expand.grid(1:ncol(data), 1:ncol(data), stringsAsFactors = F)
super_graph <- tmp[tmp[, 1] != tmp[, 2], ] - 1 #
super_graph <- super_graph[, c(2, 1)]

rdi_list <- calculate_rdi_multiple_run_cpp(data + noise, delay = c(1), run_vec - 1, as.matrix(super_graph), method = 1, turning_points = 0) #* 100 + noise

dimnames(rdi_list$max_rdi_value) <- list(gene_name_vec, gene_name_vec)
con_rdi_res_test <- calculate_multiple_run_conditioned_rdi_wrap(data + noise, as.matrix(super_graph), as.matrix(rdi_list$max_rdi_value), as.matrix(rdi_list$max_rdi_delays), run_vec - 1, 1)
dimnames(con_rdi_res_test) <- list(gene_name_vec, gene_name_vec)

# visualize the network by heatmap
pheatmap::pheatmap(rdi_list$max_rdi_value, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)
pheatmap::pheatmap(con_rdi_res_test, cluster_rows = F, cluster_cols = F, annotation_names_col = T, border_color = NA)

# in the following, I will show how to visualize a large scale network
# load the network:
load("/Users/xqiu/Dropbox (Personal)/Projects/Monocle2_revision/RData/res") #load the res (we need to mannually set the initial_nodes 1:2 in .process_graph1 function)

plot_causal_network(res$g, type = 'igraph', layout = layout_in_circle)
# plot_network(res$g, type = 'hiearchy')
plot.netbiov(res)
plot_causal_network(res$g, type = 'arcdiagram')


## ----citation, eval=TRUE-------------------------------------------------
citation("Scribe")

## ----sessi---------------------------------------------------------------
sessionInfo()

